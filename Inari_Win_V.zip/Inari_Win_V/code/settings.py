from tkinter import *
import tkinter.font as f
#dimensions de la fenetre
screen_width = 1280
screen_height = 720

tile_size = screen_height//15  #Règle la taille des blocks a modifier si besoin (écran trop petit)
#regle le nombre de frame par secondes a 60
FPS = 60

#Données sur les monstres boss et skeleton
mob_data = {
    'boss': {'health':500, 'damage': 15, 'boss_sound': '../sounds/boss/sound_boss.mp3', 'speed': 3.5,  'attack_radius': 60,  'notice_radius': 450, 'knockback': 2},
    'skeleton': {'health':40, 'damage': 5, 'death_sound':'../sounds/skeleton/death.mp3', 'speed': 2, 'attack_radius': 30, 'notice_radius': 350, 'knockback': 3}
}

speech ={
    1:"Salutations jeune aventurier, pourrais tu m'aider ? Je suis à la recherche de pierres rares",
    2:'Oui je pense pouvoir vous aider',
    3:'Très bien ! Tu trouveras ces pierres sur les monstres que tu vaincras...',
    4:"En échange, je suis pret à te donner des objets qui pourraient t'être utile pour trouver la sortie de ce lieu !",
    5:'Merci beaucoup !',
    6:'Aussi je te met en garde, cet endroit regorge de pièges. Certaines portes te ramènent à ton point de départ !',
    7:'menu',
    8:'A la prochaine !',
    9:'Ah te revoilà !'
}

player_stats = {'health': 100, 'speed' : 4, 'damage': 15, 'stamina': 200, 'max_health': 200, 'max_speed':7, 'max_stamina':300, 'max_damage':30}

bar_height = 20 #hauteur barre de vie
health_bar_width = player_stats['health'] *2  #largeur barre de vie
stamina_bar_width = player_stats['stamina'] * 0.8
ui_font = 'Fixedsys' #police pour l'interface utilisateur
ui_pygame_font = "../graphics/autres/Fixedsys.ttf" #../graphics/autres/8514fix.ttf
ui_font_size = 30   #taille de la police

def double_fonction(*funcs): # fonction permettant de faire 2 actions sur 1 bouton (impossible de base sur tkinter, et trouvé sur internet)
    def double_fonction(*fonct1, **fonct2):
        for f in funcs:
            f(*fonct1, **fonct2)
    return double_fonction

def destroy_widgets(widget_list):
    if widget_list != []:
        for widget in widget_list:
            widget.destroy()

widget_list = []